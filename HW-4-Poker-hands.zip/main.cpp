#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std; 

bool  containsPair(int hand[])
{
  bool pair = false;
  const int numCard = 5;
  for (int cardsIndex = 0; cardsIndex < numCard-1; cardsIndex++)
  {
    for (int comparisonIndex = cardsIndex + 1; comparisonIndex < numCard; comparisonIndex++) 
    {
      if (hand[cardsIndex] == hand[comparisonIndex])
        pair = true;
    }
  }  
  return pair;
}

bool  containsTwoPair(int hand[])
{
  
  int pairCards = 0; 
  const int numCard = 5;
  for (int cardsIndex = 0; cardsIndex < numCard; cardsIndex++)
  {
    for (int comparisonIndex = cardsIndex +1; comparisonIndex < numCard; comparisonIndex++) 
    {
      if (hand[cardsIndex] == hand[comparisonIndex])
      {
        pairCards ++;

      }
        
    }
  } 
  if (pairCards == 2 )
  {
    return true;
  }
  else
    return false;
  
  return 0;
}

bool  containsThreeOfaKind(int hand[])
{
  bool threeOfaKind = false;
  int sameCards = 0; 
  const int numCard = 5;
  for (int cardsIndex = 0; cardsIndex < numCard; cardsIndex++)
  {
    for (int comparisonIndex = cardsIndex + 1; comparisonIndex < numCard; comparisonIndex++) 
    {
      if (hand[cardsIndex] == hand[comparisonIndex])
        sameCards++;

    }
  if (sameCards == 2 )
  {
    return true;
  }
  else
    return false;
  }
  return threeOfaKind;
}
bool  containsFourOfaKind(int hand[])
{
  bool fourOfaKind = false;
  const int numCard = 5;
  for (int cardsIndex = 0; cardsIndex < numCard-1; cardsIndex ++ )
  {
    int sameCards = 0;
    for (int comparisonIndex = cardsIndex + 1; comparisonIndex < numCard; comparisonIndex ++ )
    {
      if (hand[comparisonIndex] == hand[cardsIndex])
      {
         sameCards ++ ;
      } 
    }
    if (sameCards == 3)
      fourOfaKind = true;
  }
  return fourOfaKind; 
}

bool  containsStraight(int hand[])
{
  int low = hand [0];
  int numCards = 5;
  for (int i = 0; i < numCards; i++)
  {
    if (hand[i] < low)
    {
       low = hand[i];
    }
      
    for (int i = 1; i <= 4; i++)
    {
      bool hasStraight = false;
        for (int cardsIndex = 0; cardsIndex < numCards; cardsIndex ++)
        {
          if (hand[cardsIndex] == (low + i) or hand[cardsIndex] == (low - i))
          {
            hasStraight = true;
          }
     
        }
        if (hasStraight == false )
        {
          return false;
        }
      
    }
        
    return true;
  }
  return 0;
}


bool  containsFullHouse(int hand[])
{
  int numCard = 5;
  int threeOfaKind =0;
  
  for (int cardsIndex =0; cardsIndex < numCard ; cardsIndex ++)
  { 
    int sameCards = 0; 
    for (int comparisonIndex = cardsIndex +1 ; 
    comparisonIndex < numCard; comparisonIndex++)
    {
      if (hand[comparisonIndex]== hand[cardsIndex])
      {
        sameCards ++;
      }
      if (sameCards == 2)
      {
        threeOfaKind = hand [cardsIndex];
        break;
        
      }
    }
  }
  if (threeOfaKind == 0)
    return false;


  for (int i = 0; i < numCard; i++)
  {
    for (int comIndex = i+1; comIndex < numCard; comIndex ++)
    {
      if (hand[i] == hand[comIndex] && hand[i] != threeOfaKind )
        return true;
    }
    return false;
  }
  return 0;
}

int main() 
{
  int input; 
  int hand[5];
  cout << "Enter five numeric cards, no face cards. Use 2-9. " << endl; 
  for (int i = 0; i < 5; i++)
  {
    cout << "Card " << i+1 << ": ";
    cin >> hand[i];
  }
  if (containsFullHouse(hand))
    cout << "Full House! " << endl;

  else if (containsFourOfaKind(hand))
    cout << "Four of a Kind!"<< endl;
  
  else if (containsThreeOfaKind(hand))
  {
    cout << "Three of a Kind." << endl;
  }
   
  else if (containsTwoPair(hand))
  {
    cout << "Two pair!" << endl;
  }
  
  else if (containsPair(hand)) 
  {
    cout << "Pair!" << endl;
  }
 
  else if (containsStraight(hand))
    cout << "Straight!"<< endl;

  else 
    cout << "High card! " << endl ;

  return 0;
}